using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginReg.Models
{

        public class Enthusiast
        {
            [Key]
            public int EnthusiastId {get;set;}
            public int UserId {get;set;}
            public int HobbyId {get;set;}
            public Hobby Hobby { get; set; }
            public User User { get; set; }
            
        }
}