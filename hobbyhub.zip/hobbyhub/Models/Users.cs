using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
    
namespace LoginReg.Models
{

    public class User
    {
        [Key]
        public int UserId {get;set;}
        [Required(ErrorMessage = "This needs 2 letters")]
        [MinLength(2)]
        public string FirstName {get;set;}
        [Required]
        [MinLength(2)]
        public string LastName {get;set;}
        [Required(ErrorMessage ="Min 3, Max15")]
        [MinLength(3)]
        [MaxLength(15)]
        public string UserName {get;set;}
        [DataType(DataType.Password)]
        [Required]
        [MinLength(8, ErrorMessage="Password must be 8 characters or longer!")]
        public string Password {get;set;}
        public DateTime CreatedAt {get;set;} = DateTime.Now;
        public DateTime UpdatedAt {get;set;} = DateTime.Now;
        // Will not be mapped to your users table!
        [NotMapped]
        [Compare("Password")]
        [DataType(DataType.Password)]
        public string Confirm {get;set;}

        public List<Enthusiast> JoinedThese {get;set;}

        public List<Hobby> MadeThese {get;set;}
    }    
}
