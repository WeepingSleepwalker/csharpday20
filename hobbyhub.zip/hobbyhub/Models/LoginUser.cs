using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginReg.Models
{
    public class LoginUser
    {
        // No other fields!
        public string UserName {get; set;}
        public string Password { get; set; }
    }
}