using System.Collections.Generic;

namespace LoginReg.Models
{
    public class DashboardView
    {
        public List<Hobby> Hobbys { get; set; }

        public int LoggedInUserId { get; set; }

        public DashboardView() {}

        public DashboardView(List<Hobby> hobbys, int userId)
        {
            Hobbys = hobbys;
            LoggedInUserId = userId;
        }
    }
}
