using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
    
namespace LoginReg.Models
{
        public class Hobby
        {
            [Key]
            public int HobbyId {get;set;}

            public int UserId {get;set;}
            
            [Required(ErrorMessage = "This needs 2 letters")]
            [MinLength(2)]
            public string HobbyName {get;set;}
            [Required(ErrorMessage = "This needs 2 letters")]
            [MinLength(2)]
            public string Description {get;set;}
            public DateTime CreatedAt {get;set;} = DateTime.Now;
            public DateTime UpdatedAt {get;set;} = DateTime.Now;

            public List<Enthusiast> UsersInside {get;set;}
            
        }

}