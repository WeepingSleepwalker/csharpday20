using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using LoginReg.Models;


namespace LoginReg.Controllers
{
    public class HomeController : Controller
    {
        private MyContext dbContext;

        public HomeController(MyContext context)
        {
            dbContext = context;
        }

        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            System.Console.WriteLine("Inside Index");

            return View();
        }

        [HttpPost("register")]
        public IActionResult Register(User user)
        {
            System.Console.WriteLine("Inside register");
            // Check initial ModelState
            if (ModelState.IsValid)
            {
                // If a User exists with provided UserName
                if (dbContext.Users.Any(u => u.UserName == user.UserName))
                {
                    // Manually add a ModelState error to the UserName field, with provided
                    // error message
                    ModelState.AddModelError("UserName", "UserName already in use!");

                    return View("Index", user);

                }
                HttpContext.Session.SetInt32("UserSessionID", user.UserId);
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                user.Password = Hasher.HashPassword(user, user.Password);
                //password hashing
                dbContext.Add(user);

                dbContext.SaveChanges();
                return RedirectToAction("DispLogin");
            }

            else
            {
                return View("Index", user);
            }


            // other code
        }

        [HttpGet("Login")]
        public IActionResult DispLogin()
        {
            return View("Login");
        }

        [HttpPost("LoginCheck")]
        public IActionResult LoginCheck(LoginUser user)
        {
            if (ModelState.IsValid)
            {

                var userInDb = dbContext.Users.FirstOrDefault(u => u.UserName == user.UserName);

                if (userInDb == null)
                {
                    ModelState.AddModelError("UserName", "Invalid UserName/Password");
                    return View("Login");
                }

                var hasher = new PasswordHasher<LoginUser>();

                // verify provided password against hash stored in db
                var result = hasher.VerifyHashedPassword(user, userInDb.Password, user.Password);

                // result can be compared to 0 for failure
                if (result == 0)
                {
                    ModelState.AddModelError("UserName", "Invalid UserName/Password");
                    return View("Login");// handle failure (this should be similar to how "existing UserName" is handled)
                    
                }
                HttpContext.Session.SetInt32("UserSessionId", userInDb.UserId);
            }
            
            return RedirectToAction("Dashboard");
        }

        [HttpGet("Dashboard")]
        public IActionResult Dashboard()
        {
            int? LoggedInUserId = HttpContext.Session.GetInt32("UserSessionId");
            if(LoggedInUserId == null)
            {
                return RedirectToAction("Index");
            }
            List<Hobby> AllHobbys = dbContext.Hobbys
                                        .Include(t => t.UsersInside)
                                        .ThenInclude(t => t.User)
                                        .ToList();

            DashboardView ToDisplay = new DashboardView(AllHobbys, (int)LoggedInUserId);
          
            return View("Dashboard", ToDisplay);
        }

        [HttpGet("hobby/new")]
        public IActionResult NewHobby()
       {
            int? LoggedInUserId = HttpContext.Session.GetInt32("UserSessionId");
            if(LoggedInUserId == null)
            {
                return RedirectToAction("Index");
            }
            return View();

       } 

       [HttpPost("hobby/create")]
       public IActionResult CreateHobby(Hobby ToCreate)
       {
            int? LoggedInUserId = HttpContext.Session.GetInt32("UserSessionId");
            if(LoggedInUserId == null)
            {
                return RedirectToAction("Index");
            }
            if(ModelState.IsValid)
            {
                ToCreate.UserId = (int)LoggedInUserId;

                dbContext.Add(ToCreate);
                dbContext.SaveChanges();
                return RedirectToAction("Dashboard");
            }
            else {
                return View("NewHobby");
            }

       }

       [HttpGet("hobby/enthusiasts/{hobbyId}")]
       public IActionResult ShowEnthusiasts(int hobbyId)
       {
           ViewBag.GetHobby = dbContext.Hobbys.SingleOrDefault(l => l.HobbyId == hobbyId);

           ViewBag.GetGuests = dbContext.Hobbys
                                .Include(p=> p.UsersInside)
                                .ThenInclude(o => o.User)
                                .FirstOrDefault(l => l.HobbyId == hobbyId);
            return View();
       }

      [HttpGet("hobby/enthusiast/{hobbyId}")]

        public IActionResult CreateEnthusiast(int hobbyId, Enthusiast ToCreate)
       {
            int? LoggedInUserId = HttpContext.Session.GetInt32("UserSessionId");
            if(LoggedInUserId == null)
            {
                return RedirectToAction("Index");
            }
            ToCreate.UserId = (int)LoggedInUserId;
            ToCreate.HobbyId = hobbyId;

            dbContext.Add(ToCreate);
            dbContext.SaveChanges();
            return RedirectToAction("Dashboard");
            
       }

        [HttpGet("logout")]
        public RedirectToActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }



    }
}